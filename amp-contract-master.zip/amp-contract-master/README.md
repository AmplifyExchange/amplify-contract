Amplify Contract
================

Getting Started
---------------

to run everything:

`ci/all.sh`

to install dependencies:

`ci/setup.sh`

to lint:

`ci/lint.sh`

to run the tests:

`ci/test.sh`