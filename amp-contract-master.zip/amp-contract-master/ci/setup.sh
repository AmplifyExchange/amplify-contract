#!/bin/bash -xv

npm install
