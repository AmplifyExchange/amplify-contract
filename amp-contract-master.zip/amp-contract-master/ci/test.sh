#!/bin/bash -xev

npm test
