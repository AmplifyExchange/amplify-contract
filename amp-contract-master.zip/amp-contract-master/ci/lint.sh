#!/bin/bash -xv

npm run lint
